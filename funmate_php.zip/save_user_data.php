<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

error_reporting(E_ALL);
ini_set('display_errors', 0);

try {
    include "db_connection.php";
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => "Database connection failed"]);
    exit;
}

$raw = file_get_contents("php://input");
error_log("RAW INPUT: " . $raw);

if (empty($raw)) {
    echo json_encode(["success" => false, "message" => "No input data received"]);
    exit;
}

$data = json_decode($raw, true);
if (json_last_error() !== JSON_ERROR_NONE) {
    echo json_encode(["success" => false, "message" => "Invalid JSON: " . json_last_error_msg()]);
    exit;
}

// Extract data - handle both field names
$uid = $data['uid'] ?? '';
$name = $data['name'] ?? '';
$email = $data['email'] ?? '';
$device_id = $data['device_id'] ?? '';
$idToken = $data['idToken'] ?? '';
$coins = intval($data['coins'] ?? 0);
// Handle both dailyLimits and daily_limits
$dailyLimits = intval($data['dailyLimits'] ?? $data['daily_limits'] ?? 0);
$subject = strtolower($data['subject'] ?? '');

// Validate required fields
if (empty($uid) || empty($email)) {
    echo json_encode([
        "success" => false, 
        "message" => "Missing required fields: uid or email"
    ]);
    exit;
}

// FIXED: Corrected variable name from $subjectColums to $subjectColumns
$subjectColumns = [
    'alphabetfun' => 'alphabet_fun_daily_limit',
    'bigvssmall' => 'bigvssmall_fun_daily_limit',
    'dailycheckin' => 'daily_checkin_daily_limit',
    'gamefun' => 'game_fun_daily_limit',
    'mathfun' => 'math_fun_daily_limit',
    'soundfun' => 'sound_fun_daily_limit',
];

// FIXED: Corrected variable name from $subjectDataColumns to $subjectDateColumns
$subjectDateColumns = [
    'alphabetfun' => 'alphabet_fun_last_date',
    'bigvssmall' => 'bigvssmall_fun_last_date',
    'dailycheckin' => 'daily_checkin_last_date',
    'gamefun' => 'game_fun_last_date',
    'mathfun' => 'math_fun_last_date',
    'soundfun' => 'sound_fun_last_date',
];

$today = date('Y-m-d');

// Check if subject is provided and valid
if (!empty($subject)) {
    if (!isset($subjectColumns[$subject])) {
        echo json_encode([
            "success" => false,
            "message" => "Invalid subject: $subject. Available: " . implode(', ', array_keys($subjectColumns))
        ]);
        exit;
    }
    $dailyLimitColumn = $subjectColumns[$subject];
    $dateColumn = $subjectDateColumns[$subject];
} else {
    $dailyLimitColumn = null;
    $dateColumn = null;
}

error_log("Processing $subject data for $email: coins=$coins, limits=$dailyLimits");

try {
    if (!empty($subject) && $dailyLimitColumn) {
        // NEW WAY: Subject-specific columns
        $stmt = $pdo->prepare("SELECT id, coins, $dailyLimitColumn, $dateColumn FROM users WHERE uid = ? OR email = ?");
        $stmt->execute([$uid, $email]);
        
        if ($stmt->rowCount() > 0) {
            // User exists - UPDATE
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            $userId = $user['id'];
            $currentCoins = intval($user['coins'] ?? 0);
            $currentSubjectLimit = intval($user[$dailyLimitColumn] ?? 0);
            $lastDate = $user[$dateColumn];
            
            // Reset daily limit if it's a new day
            if ($lastDate !== $today) {
                $currentSubjectLimit = 0;
            }
            
            // FIXED: Add coins properly and update subject limit
            $newTotalCoins = $currentCoins + $coins;
            $newSubjectLimit = $dailyLimits; // Current progress
            
            $updateQuery = "UPDATE users SET 
                uid = ?, name = ?, email = ?, device_id = ?, 
                coins = ?, $dailyLimitColumn = ?, $dateColumn = ? 
                WHERE id = ?";
            
            $updateStmt = $pdo->prepare($updateQuery);
            $updateStmt->execute([
                $uid, $name, $email, $device_id, 
                $newTotalCoins, $newSubjectLimit, $today, $userId
            ]);
            
            error_log("Updated user $userId: coins $currentCoins + $coins = $newTotalCoins, {$subject}_limit=$newSubjectLimit");
        } else {
            // New user - INSERT
            $insertQuery = "INSERT INTO users (
                uid, name, email, device_id, idToken, coins, $dailyLimitColumn, $dateColumn
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            
            $stmt = $pdo->prepare($insertQuery);
            $stmt->execute([$uid, $name, $email, $device_id, $idToken, $coins, $dailyLimits, $today]);
            $userId = $pdo->lastInsertId();
            $newTotalCoins = $coins;
            $newSubjectLimit = $dailyLimits;
            
            error_log("Created new user $userId: coins=$coins, {$subject}_limit=$dailyLimits");
        }
    } else {
        // OLD WAY: Using dailyLimits column (backward compatibility)
        $stmt = $pdo->prepare("SELECT id, coins FROM users WHERE uid = ? OR email = ?");
        $stmt->execute([$uid, $email]);
        
        if ($stmt->rowCount() > 0) {
            // User exists - UPDATE
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            $userId = $user['id'];
            $currentCoins = intval($user['coins'] ?? 0);
            $newTotalCoins = $currentCoins + $coins; // FIXED: Define $newTotalCoins
            
            $updateStmt = $pdo->prepare("UPDATE users SET uid = ?, name = ?, email = ?, device_id = ?, coins = ? WHERE id = ?");
            $updateStmt->execute([$uid, $name, $email, $device_id, $newTotalCoins, $userId]);
            
            $newSubjectLimit = $dailyLimits;
            error_log("Updated user $userId (old way): coins $currentCoins + $coins = $newTotalCoins");
        } else {
            // New user - INSERT
            $stmt = $pdo->prepare("INSERT INTO users (uid, name, email, device_id, coins) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$uid, $name, $email, $device_id, $coins]);
            $userId = $pdo->lastInsertId();
            $newTotalCoins = $coins;
            $newSubjectLimit = $dailyLimits;
            
            error_log("Created new user $userId (old way): coins=$coins");
        }
    }
    
    // Generate token
    $token = bin2hex(random_bytes(16));
    $tokenStmt = $pdo->prepare("UPDATE users SET token = ? WHERE id = ?");
    $tokenStmt->execute([$token, $userId]);
    
    // Get updated user data to return all subject limits
    $allDataStmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $allDataStmt->execute([$userId]);
    $fullUserData = $allDataStmt->fetch(PDO::FETCH_ASSOC);
    
    // Success response
    echo json_encode([
        "success" => true,
        "token" => $token,
        "message" => "Data saved successfully for $subject",
        "user" => [
            "id" => $userId,
            "uid" => $uid,
            "name" => $name,
            "email" => $email,
            "coins" => $newTotalCoins,
            "subject" => $subject,
            "daily_limit" => $newSubjectLimit,
            
            // Return all subject limits for debugging
            "alphabet_fun_daily_limit" => intval($fullUserData['alphabet_fun_daily_limit'] ?? 0),
            "mathfun_daily_limit" => intval($fullUserData['math_fun_daily_limit'] ?? 0),
            "bigvssmall_daily_limit" => intval($fullUserData['bigvssmall_fun_daily_limit'] ?? 0),
        ]
    ]);
    
    error_log("SUCCESS: User $userId, Total Coins: $newTotalCoins, $subject Progress: $newSubjectLimit");
    
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    echo json_encode(["success" => false, "message" => "Database error: " . $e->getMessage()]);
}
?>